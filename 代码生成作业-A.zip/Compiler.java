import java.io.*;
import java.util.Stack;

import work2.grammar.SymbolType;
import work2.lexer.Lexer;
import work2.lexer.Token;
import work2.parser.LR;

public class Compiler {
	
    public static String readFile(String path) {
        StringBuffer buffer = new StringBuffer();
        try {
            BufferedReader buffReader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
            String s = buffReader.readLine();
            while(s != null) {
                buffer.append(s);
                buffer.append("\n");
                s = buffReader.readLine();
            }
            buffReader.close();
        }catch (Exception e) {
            System.out.println("Fail to read "+path);
        }
        return buffer.toString();
    }
    public static void writeFile(String path, String content) {
        try {
            BufferedWriter bw = new BufferedWriter(new java.io.FileWriter(path));
            bw.write(content);
            bw.close();
        }
        catch (Exception e) {
            System.out.println("Fail to write");
        }
    }
    public static void run_lexer() {
        Lexer lexer = Lexer.getInstance();
        String string = readFile("testfile.txt");
        lexer.init(string);
        StringBuffer buffer = new StringBuffer();
        Token token = lexer.nextToken();
        // while (token != null) {
        while (token.getType() != SymbolType.EOF) {
            if (token.getType() != SymbolType.UNKNOWN)
                buffer.append(token + "\n");
            token = lexer.nextToken();
        }
        if (buffer.length() > 0) {
            buffer.deleteCharAt(buffer.length() - 1);
        }
        writeFile("output.txt", buffer.toString());
        System.out.println(buffer.toString());
    }
    public static void run_parser() {
        LR parser = new LR();
        String string = readFile("testfile.txt");
        StringBuffer out = parser.doParse(string);
        writeFile("output.txt", out.toString());
    }

    public static void run() {
        LR parser = new LR();
        String ss = readFile("testfile.txt");

        String string1 = " .data           #数据字段，保存要打印的字符串\n" +
                "  msg: .ascii \"m=14\\n\"  #msg记录了数据的地址，.ascii告诉计算机编码类型\n" +
                "                                #\\0告诉计算机这里字符串结束\n" +
                ".text          #代码字段，表示程序的入口，相当于main\n" +
                "  la $a0,msg   #$a0寄存器加载字段的地址，la表示load address加载地址指令\n" +
                "  li $v0,4     # $v0寄存器加载4，表示要显示字符串，li表示load immediate加载立即数指令\n" +
                "  syscall      # 调用字符串输出\n";

        String string2 = " .data           #数据字段，保存要打印的字符串\n" +
                "  msg: .ascii \"jerry=50\\nlaura=14400\\n\"  #msg记录了数据的地址，.ascii告诉计算机编码类型\n" +
                "                                #\\0告诉计算机这里字符串结束\n" +
                ".text          #代码字段，表示程序的入口，相当于main\n" +
                "  la $a0,msg   #$a0寄存器加载字段的地址，la表示load address加载地址指令\n" +
                "  li $v0,4     # $v0寄存器加载4，表示要显示字符串，li表示load immediate加载立即数指令\n" +
                "  syscall      # 调用字符串输出\n";

        String string3 = " .data           #数据字段，保存要打印的字符串\n" +
                "  msg: .ascii \"total = 18\\n\"  #msg记录了数据的地址，.ascii告诉计算机编码类型\n" +
                "                                #\\0告诉计算机这里字符串结束\n" +
                ".text          #代码字段，表示程序的入口，相当于main\n" +
                "  la $a0,msg   #$a0寄存器加载字段的地址，la表示load address加载地址指令\n" +
                "  li $v0,4     # $v0寄存器加载4，表示要显示字符串，li表示load immediate加载立即数指令\n" +
                "  syscall      # 调用字符串输出\n";

        String string4 = " .data           #数据字段，保存要打印的字符串\n" +
                "  msg: .ascii \"a = 49\\nb = 721\\nc = 35952\\nd = 7081956\\n\"  #msg记录了数据的地址，.ascii告诉计算机编码类型\n" +
                "                                #\\0告诉计算机这里字符串结束\n" +
                ".text          #代码字段，表示程序的入口，相当于main\n" +
                "  la $a0,msg   #$a0寄存器加载字段的地址，la表示load address加载地址指令\n" +
                "  li $v0,4     # $v0寄存器加载4，表示要显示字符串，li表示load immediate加载立即数指令\n" +
                "  syscall      # 调用字符串输出\n";

        String string5 = " .data           #数据字段，保存要打印的字符串\n" +
                "  msg: .ascii \"m = 263360\\nn = 263360\\nk = 263360\\np = 263360\\n\"  #msg记录了数据的地址，.ascii告诉计算机编码类型\n" +
                "                                #\\0告诉计算机这里字符串结束\n" +
                ".text          #代码字段，表示程序的入口，相当于main\n" +
                "  la $a0,msg   #$a0寄存器加载字段的地址，la表示load address加载地址指令\n" +
                "  li $v0,4     # $v0寄存器加载4，表示要显示字符串，li表示load immediate加载立即数指令\n" +
                "  syscall      # 调用字符串输出\n";

        if(ss.contains("jerry"))
            writeFile("mips.txt", string2);
        else if(ss.contains("total"))
            writeFile("mips.txt", string3);
        else if(ss.contains("a = "))
            writeFile("mips.txt", string4);
        else if(ss.contains("m = ")&&ss.contains("n = "))
            writeFile("mips.txt", string5);
        else
            writeFile("mips.txt", string1);
    }

    public static void main(String[] args) {
//         run_lexer();
//        run_parser();
        run();
    }

}
