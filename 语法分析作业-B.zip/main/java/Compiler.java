import java.io.*;
import java.util.Stack;

import work2.grammar.SymbolType;
import work2.lexer.Lexer;
import work2.lexer.Token;
import work2.parser.LR;

public class Compiler {
	
    public static String readFile(String path) {
        StringBuffer buffer = new StringBuffer();
        try {
            BufferedReader buffReader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
            String s = buffReader.readLine();
            while(s != null) {
                buffer.append(s);
                buffer.append("\n");
                s = buffReader.readLine();
            }
            buffReader.close();
        }catch (Exception e) {
            System.out.println("Fail to read "+path);
        }
        return buffer.toString();
    }
    public static void writeFile(String path, String content) {
        try {
            BufferedWriter bw = new BufferedWriter(new java.io.FileWriter(path));
            bw.write(content);
            bw.close();
        }
        catch (Exception e) {
            System.out.println("Fail to write");
        }
    }
    public static void run_lexer() {
        Lexer lexer = Lexer.getInstance();
        String string = readFile("testfile.txt");
        lexer.init(string);
        StringBuffer buffer = new StringBuffer();
        Token token = lexer.nextToken();
        // while (token != null) {
        while (token.getType() != SymbolType.EOF) {
            if (token.getType() != SymbolType.UNKNOWN)
                buffer.append(token + "\n");
            token = lexer.nextToken();
        }
        if (buffer.length() > 0) {
            buffer.deleteCharAt(buffer.length() - 1);
        }
        writeFile("output.txt", buffer.toString());
        System.out.println(buffer.toString());
    }
    public static void run_parser() {
        LR parser = new LR();
        String string = readFile("testfile.txt");
        StringBuffer out = parser.doParse(string);
        writeFile("output.txt", out.toString());
    }
    public static void main(String[] args) {
//         run_lexer();
        run_parser();
    }

}
