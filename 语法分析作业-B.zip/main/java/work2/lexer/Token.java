package work2.lexer;

import work2.grammar.SymbolType;

public class Token {
    public SymbolType type;
    public String token;
    private int line; 

    public Token(SymbolType type, String token, int line) {
        this.type = type;
        this.token = token;
        this.line = line;
    }
    
    public SymbolType getType() {
        return type;
    }

    public int getLine(){
    	return line;
    }
    
    
    public String getLexeme(){
        return token;
    }
    
    public String toString() {
        if(token!=null)
    	    return type.toString() + " " + token;
        return type.toString();
    }
}