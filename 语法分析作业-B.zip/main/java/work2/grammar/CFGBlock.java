package work2.grammar;


import work2.parser.LRTable;
import work2.parser.LRTableEntry;

import java.util.ArrayList;
import java.util.HashMap;

public class CFGBlock extends CFG{

	/*
	0)  CompUnit → Block
	1)  Block → '{' BlockItemList '}'
	2)  BlockItemList →  BlockItemList BlockItem 
	3)  BlockItemList →  EPSILON
	4)  BlockItem → VarDecl
	5)  BlockItem → Stmt
	6)  VarDecl → 'int' VarDeclList ';' 
	7)  VarDeclList → VarDeclList  ',' VarDef
	8)  VarDeclList → VarDef
	9)  VarDef → Ident
	
	10) VarDef → Ident '=' Exp
	11) Stmt → Ident '=' Exp ';' 
	12) Stmt → Exp ';'
	13) Stmt → ';'
	14) Stmt → Block
	15) Stmt → 'if' '(' Cond ')' Block
	16) Stmt → 'if' '(' Cond ')' Block 'else' Block
	17) Stmt → 'while' '(' Cond ')' Block
	18) Stmt → Ident '=' 'getint''('')'';'
	19) Stmt → 'printf''('FormatString ExpList ')'';' 
	
	20) ExpList → ExpList ',' Exp
	21) ExpList → EPSILON
	22) Exp → AddExp 
	23) Cond → LOrExp 
	24) PrimaryExp → '(' Exp ')'
	25) PrimaryExp → Ident
	26) PrimaryExp → IntConst 
	27) UnaryExp → PrimaryExp
	28) MulExp → UnaryExp 
	29) MulExp → MulExp '*' UnaryExp
	
	30) MulExp → MulExp '/' UnaryExp 
	31) MulExp → MulExp '%' UnaryExp 
	32) AddExp → MulExp
	33) AddExp → AddExp '+' MulExp
	34) AddExp → AddExp '-' MulExp 
	35) RelExp → AddExp
	36) RelExp → RelExp '<' AddExp
	37) RelExp → RelExp '>' AddExp 
	38) RelExp → RelExp '<=' AddExp 
	39) RelExp → RelExp '>=' AddExp  
	
	40) EqExp → RelExp
	41) EqExp → EqExp '==' RelExp 
	42) EqExp → EqExp '!=' RelExp 
	43) LAndExp → EqExp
	44) LAndExp → LAndExp '&&' EqExp 
	45) LOrExp → LAndExp
	46) LOrExp → LOrExp '||' LAndExp
	 */
	public void init() {
		this.setStartSymbol(SymbolType.CompUnit);
		Production p = null;
		//0) CompUnit → Block 
		p = new Production(SymbolType.CompUnit, SymbolType.Block);
		addProduction(p);
		//1)  Block → '{' BlockItemList '}'
		p = new Production(SymbolType.Block, SymbolType.LBRACE, SymbolType.BlockItemList, SymbolType.RBRACE);
		addProduction(p);
		//2)  BlockItemList →  BlockItemList BlockItem 
		p = new Production(SymbolType.BlockItemList, SymbolType.BlockItemList, SymbolType.BlockItem);
		addProduction(p);
		//3)  BlockItemList →  EPSILON
		p = new Production(SymbolType.BlockItemList, SymbolType.EPSILON);
		addProduction(p);
		//4)  BlockItem → VarDecl
		p = new Production(SymbolType.BlockItem, SymbolType.VarDecl);
		addProduction(p);
		//5)  BlockItem → Stmt
		p = new Production(SymbolType.BlockItem, SymbolType.Stmt);
		addProduction(p);
		//6)  VarDecl → 'int' VarDeclList ';' 
		p = new Production(SymbolType.VarDecl, SymbolType.INTTK, SymbolType.VarDeclList, SymbolType.SEMICN);
		addProduction(p);
		//7)  VarDeclList → VarDeclList  ',' VarDef
		p = new Production(SymbolType.VarDeclList, SymbolType.VarDeclList, SymbolType.COMMA, SymbolType.VarDef);
		addProduction(p);
		//8)  VarDeclList → VarDef
		p = new Production(SymbolType.VarDeclList, SymbolType.VarDef);
		addProduction(p);
		//9)  VarDef → Ident
		p = new Production(SymbolType.VarDef, SymbolType.IDENFR);
		addProduction(p);
		
		//10) VarDef → Ident '=' Exp
		p = new Production(SymbolType.VarDef, SymbolType.IDENFR, SymbolType.ASSIGN, SymbolType.Exp);
		addProduction(p);
		//11) Stmt → Ident '=' Exp ';'
		p = new Production(SymbolType.Stmt, SymbolType.IDENFR, SymbolType.ASSIGN, SymbolType.Exp, SymbolType.SEMICN);
		addProduction(p);
		//12) Stmt → Exp ';'
		p = new Production(SymbolType.Stmt, SymbolType.Exp, SymbolType.SEMICN);
		addProduction(p);
		//13) Stmt → ';'
		p = new Production(SymbolType.Stmt, SymbolType.SEMICN);
		addProduction(p);
		//14) Stmt → Block
		p = new Production(SymbolType.Stmt, SymbolType.Block);
		addProduction(p);
		//15) Stmt → 'if' '(' Cond ')' Block
		p = new Production(SymbolType.Stmt, SymbolType.IFTK, SymbolType.LPARENT, SymbolType.Cond, SymbolType.RPARENT, SymbolType.Block);
		addProduction(p);				
		//16) Stmt → 'if' '(' Cond ')' Block 'else' Block
		p = new Production(SymbolType.Stmt, SymbolType.IFTK, SymbolType.LPARENT, SymbolType.Cond, SymbolType.RPARENT, SymbolType.Block, SymbolType.ELSETK, SymbolType.Block);
		addProduction(p);
		//17) Stmt → 'while' '(' Cond ')' Stmt
		p = new Production(SymbolType.Stmt, SymbolType.WHILETK, SymbolType.LPARENT, SymbolType.Cond, SymbolType.RPARENT, SymbolType.Stmt);
		addProduction(p);
		//18) Stmt → Ident '=' 'getint''('')'';'
		p = new Production(SymbolType.Stmt, SymbolType.IDENFR, SymbolType.ASSIGN, SymbolType.GETINTTK, SymbolType.LPARENT, SymbolType.RPARENT, SymbolType.SEMICN);
		addProduction(p);		
		//19) Stmt → 'printf''('FormatString ExpList ')'';' 
		p = new Production(SymbolType.Stmt, SymbolType.PRINTFTK, SymbolType.LPARENT, SymbolType.STRCON, SymbolType.ExpList, SymbolType.RPARENT, SymbolType.SEMICN);
		addProduction(p);
		
		//20) ExpList → ExpList ',' Exp
		p = new Production(SymbolType.ExpList, SymbolType.ExpList, SymbolType.COMMA, SymbolType.Exp);
		addProduction(p);
		//21) ExpList → EPSILON
		p = new Production(SymbolType.ExpList, SymbolType.EPSILON);
		addProduction(p);
		//22) Exp → AddExp 
		p = new Production(SymbolType.Exp, SymbolType.AddExp);
		addProduction(p);
		//23) Cond → LOrExp 
		p = new Production(SymbolType.Cond, SymbolType.LOrExp);
		addProduction(p);
		//24) PrimaryExp → '(' Exp ')' 
		p = new Production(SymbolType.PrimaryExp, SymbolType.LPARENT, SymbolType.Exp, SymbolType.RPARENT);
		addProduction(p);
		//25) PrimaryExp → Ident
		p = new Production(SymbolType.PrimaryExp, SymbolType.IDENFR);
		addProduction(p);
		//26) PrimaryExp → IntConst 
		p = new Production(SymbolType.PrimaryExp, SymbolType.INTCON);
		addProduction(p);
		//27) UnaryExp → PrimaryExp
		p = new Production(SymbolType.UnaryExp, SymbolType.PrimaryExp);
		addProduction(p);
		//28) MulExp → UnaryExp
		p = new Production(SymbolType.MulExp, SymbolType.UnaryExp);
		addProduction(p);
		//29) MulExp → MulExp '*' UnaryExp
		p = new Production(SymbolType.MulExp, SymbolType.MulExp, SymbolType.MULT, SymbolType.UnaryExp);
		addProduction(p);
		
		//30) MulExp → MulExp '/' UnaryExp 
		p = new Production(SymbolType.MulExp, SymbolType.MulExp, SymbolType.DIV, SymbolType.UnaryExp);
		addProduction(p);
		//31) MulExp → MulExp '%' UnaryExp 
		p = new Production(SymbolType.MulExp, SymbolType.MulExp, SymbolType.MOD, SymbolType.UnaryExp);
		addProduction(p);
		//32) AddExp → MulExp
		p = new Production(SymbolType.AddExp, SymbolType.MulExp);
		addProduction(p);
		//33) AddExp → AddExp '+' MulExp
		p = new Production(SymbolType.AddExp, SymbolType.AddExp, SymbolType.PLUS, SymbolType.MulExp);
		addProduction(p);
		//34) AddExp → AddExp '-' MulExp 
		p = new Production(SymbolType.AddExp, SymbolType.AddExp, SymbolType.MINU, SymbolType.MulExp);
		addProduction(p);
		//35) RelExp → AddExp
		p = new Production(SymbolType.RelExp, SymbolType.AddExp);
		addProduction(p);
		//36) RelExp → RelExp '<' AddExp
		p = new Production(SymbolType.RelExp, SymbolType.RelExp, SymbolType.LSS, SymbolType.AddExp);
		addProduction(p);
		//37) RelExp → RelExp '>' AddExp 
		p = new Production(SymbolType.RelExp, SymbolType.RelExp, SymbolType.GRE, SymbolType.AddExp);
		addProduction(p);
		//38) RelExp → RelExp '<=' AddExp  
		p = new Production(SymbolType.RelExp, SymbolType.RelExp, SymbolType.LEQ, SymbolType.AddExp);
		addProduction(p);
		//39) RelExp → RelExp '>=' AddExp  
		p = new Production(SymbolType.RelExp, SymbolType.RelExp, SymbolType.GEQ, SymbolType.AddExp);
		addProduction(p);
		
		//40) EqExp → RelExp 
		p = new Production(SymbolType.EqExp, SymbolType.RelExp);
		addProduction(p);
		//41) EqExp → EqExp '==' RelExp 
		p = new Production(SymbolType.EqExp, SymbolType.EqExp, SymbolType.EQL, SymbolType.RelExp);
		addProduction(p);
		//42) EqExp → EqExp '!=' RelExp 
		p = new Production(SymbolType.EqExp, SymbolType.EqExp, SymbolType.NEQ, SymbolType.RelExp);
		addProduction(p);
		//43) LAndExp → EqExp
		p = new Production(SymbolType.LAndExp, SymbolType.EqExp);
		addProduction(p);
		//44) LAndExp → LAndExp '&&' EqExp 
		p = new Production(SymbolType.LAndExp, SymbolType.LAndExp, SymbolType.AND, SymbolType.EqExp);
		addProduction(p);
		//45) LOrExp → LAndExp
		p = new Production(SymbolType.LOrExp, SymbolType.LAndExp);
		addProduction(p);
		//46) LOrExp → LOrExp '||' LAndExp
		p = new Production(SymbolType.LOrExp, SymbolType.LOrExp, SymbolType.OR, SymbolType.LAndExp);
		addProduction(p);

	}

	HashMap<SymbolType,Boolean>V;
	HashMap<SymbolType,Boolean>T;
	public LRTable lrTable;
	class I{
		I(){
			pros=new ArrayList<>();
		}
		ArrayList<Production>pros;
	}
	ArrayList<I>Is;
	public void init_V(){
		V=new HashMap<>();
		for(Production w:this.getProductions()){
			V.put(w.left,true);
		}
	}
	public void init_T(){
		T=new HashMap<>();
		for(Production w:this.getProductions()){
			for(SymbolType symbolType:w.right){
				if(V.get(symbolType)==null){
					T.put(symbolType,true);
				}
			}
		}
	}
	boolean is_inI(I s,Production a){
		for(int i=0;i<s.pros.size();i++){
			if(s.pros.get(i).toString().equals(a.toString())) return true;
		}
		return false;
	}
	I close(I a){
		for(int i=0;i<a.pros.size();i++){
			if(a.pros.get(i).idx==a.pros.get(i).right.size()) continue;
			if(V.get(a.pros.get(i).get_idx())!=null){
				for(int j=0;j<productions.size();j++){
					if(productions.get(j).left.toString().equals(a.pros.get(i).get_idx().toString())){
						if(!is_inI(a,productions.get(j)))
							a.pros.add(productions.get(j));
					}
				}
			}
		}
		return a;
	}
	boolean is_sameI(I a,I b){
		if(a.pros.size()!=b.pros.size()) return false;
		int i,j;
		int cnt=0;
		for(i=0;i<a.pros.size();i++){
			for(j=0;j<b.pros.size();j++){
				if(a.pros.get(i).toString().equals(b.pros.get(j).toString())){
					cnt++;
					break;
				}
			}
		}
		if(cnt==a.pros.size()) return true;
		return false;
	}
	int find(Production a){
		for(int i=0;i<productions.size();i++){
			if(productions.get(i).LR_String().equals(a.LR_String())){
				return i;
			}
		}
		return -1;
	}
	public void SLR(){
		lrTable=new LRTable();
		I t=new I();
		t.pros.add(getProduction(0));
		Is=new ArrayList<>();
		t=close(t);
		Is.add(t);
		int z=0;
		do{
			for(SymbolType m:V.keySet()){
				t=new I();
				for(int n=0;n<Is.get(z).pros.size();n++){
					Production ans=new Production();
					ans.left=Is.get(z).pros.get(n).left;
					ans.right=Is.get(z).pros.get(n).right;
					ans.idx=Is.get(z).pros.get(n).idx;
					if(ans.idx==ans.right.size()) continue;
					if(m.toString().equals(ans.get_idx().toString())){
						ans.idx++;
						t.pros.add(ans);
					}
				}
				t=close(t);
				if(t.pros.size()==0) continue;
				int u;
				for(u=0;u<Is.size();u++){
					if(is_sameI(Is.get(u),t)){
						int xx=z;
						lrTable.addItem(xx,m,new LRTableEntry('s',u));
						break;
					}
				}
				if(u==Is.size()){
					Is.add(t);
					int xx=z;
					lrTable.addItem(xx,m,new LRTableEntry('s',Is.size()-1));
				}
			}
			for(SymbolType m:T.keySet()){
				t=new I();
				for (int n = 0; n < Is.get(z).pros.size(); n++) {
					Production ans=new Production();
					ans.left=Is.get(z).pros.get(n).left;
					ans.right=Is.get(z).pros.get(n).right;
					ans.idx=Is.get(z).pros.get(n).idx;
					if(ans.idx==ans.right.size()) continue;
					if(m.toString().equals(ans.get_idx().toString())){
						ans.idx++;
						t.pros.add(ans);
					}
				}
				t=close(t);
				if(t.pros.size()==0) continue;
				int u;
				for(u=0;u<Is.size();u++){
					if(is_sameI(Is.get(u),t)){
						int xx=z;
						lrTable.addItem(xx,m,new LRTableEntry('s',u));
						break;
					}
				}
				if(u==Is.size()){
					Is.add(t);
					int xx=z;
					lrTable.addItem(xx,m,new LRTableEntry('s',Is.size()-1));
				}
			}
			z++;
		}while(z<Is.size());
		int l, xx, yy, index, r;
		for(int i=0;i<Is.size();i++){
			for(int j=0;j<Is.get(i).pros.size();j++){
				System.out.println(Is.get(i).pros.get(j)+"\n");
				if(Is.get(i).pros.get(j).idx==Is.get(i).pros.get(j).right.size()){
					xx=i;index=find(Is.get(i).pros.get(j));
					if(lrTable.table.get(xx)==null) {
						lrTable.addItem(xx,SymbolType.UNKNOWN,new LRTableEntry('r',-1));
					}
					for(SymbolType m:V.keySet()){
						if(lrTable.table.get(xx).get(m)==null){
							lrTable.addItem(xx,m,new LRTableEntry('r',index));
						}
					}
					for(SymbolType m:T.keySet()){
						if(lrTable.table.get(xx).get(m)==null){
							lrTable.addItem(xx,m,new LRTableEntry('r',index));
						}
					}
				}
			}
		}
		int tmp=0;
	}

}
