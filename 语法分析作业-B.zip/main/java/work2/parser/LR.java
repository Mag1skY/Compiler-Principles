package work2.parser;

import work2.grammar.CFG;
import work2.grammar.CFGBlock;
import work2.grammar.SymbolType;
import work2.lexer.Lexer;
import work2.lexer.Token;

import javax.swing.*;
import java.util.Stack;

public class LR {
    private Lexer lexer = null;
    private CFGBlock grammar;
    private LRTable lrTable;
    private Token lookAhead = null;
    private Stack<Integer> stateStack;
    private Stack<SymbolType> symbolStack;

    public LR() {
        this.stateStack = new Stack<Integer>();
        this.symbolStack = new Stack<SymbolType>();
        this.grammar = new CFGBlock();
        this.grammar.init();
        this.lrTable = new LRTable();
        this.lrTable.init();
    }

    public StringBuffer doParse(String str) {
        this.lexer = Lexer.getInstance();
        lexer.init(str);
        return this.parse();
    }

    public StringBuffer parse() {
        /**************** begin *******************/

        grammar.init_V();
        grammar.init_T();
        grammar.SLR();
        lrTable = grammar.lrTable;
        Token token = lexer.nextToken();
        StringBuffer buffer = new StringBuffer();
        Stack<Integer> statue = new Stack<>();
        statue.push(0);
        while (token.getType() != SymbolType.EOF) {
            if (token.getType() != SymbolType.UNKNOWN) {
                Token tmp = new Token(token.type, token.token, 1);
                while (lrTable.table.get(statue.peek()).get(token.type)!=null&&lrTable.table.get(statue.peek()).get(token.type).action == 'r') {
                    int op = lrTable.table.get(statue.peek()).get(tmp.type).state;
                    int sz = grammar.productions.get(op).getRight().size();
                    while (sz-- > 0) {
                        statue.pop();
                    }
                    tmp = new Token(grammar.productions.get(op).getLeft(), null, 0);
                    if (lrTable.table.get(statue.peek()).get(tmp.type)!=null&&lrTable.table.get(statue.peek()).get(tmp.type).action != 'r') {
                        statue.push(lrTable.table.get(statue.peek()).get(tmp.type).state);
                    }
                    buffer.append(tmp + "\n");
                    if(tmp.type.equals(SymbolType.RelExp)){
                        continue;
                    }
                }
                buffer.append(token + "\n");
                LRTableEntry lrTableEntry = lrTable.table.get(statue.peek()).get(token.getType());
                if(lrTableEntry==null) break;
                if (lrTableEntry.action == 's') {
                    statue.push(lrTableEntry.state);
                }
                if (token.type == SymbolType.LBRACE) {
                    statue.push(lrTable.table.get(statue.peek()).get(SymbolType.BlockItemList).state);
                    token.type = SymbolType.BlockItemList;
                    token.token = null;
                    buffer.append(token + "\n");
                }
                if(token.type==SymbolType.STRCON){
                    statue.push(lrTable.table.get(statue.peek()).get(SymbolType.ExpList).state);
                    token.type = SymbolType.ExpList;
                    token.token = null;
                    buffer.append(token + "\n");
                }

            }
            token = lexer.nextToken();
        }
        Token tmp = new Token(SymbolType.CompUnit, null, 1);
//        buffer.append("<Block>\n");
//        buffer.append("<CompUnit>\n");
        {
            while (statue.size() > 1) {
                int op = lrTable.table.get(statue.peek()).get(tmp.type).state;
                int sz = grammar.productions.get(op).getRight().size();
                while (sz-- > 0) {
                    statue.pop();
                }
                tmp = new Token(grammar.productions.get(op).getLeft(), null, 0);
                buffer.append(tmp + "\n");
                if(tmp.type.equals(SymbolType.CompUnit)) break;
                if(statue.size()>=1)
                    statue.push(lrTable.table.get(statue.peek()).get(tmp.type).state);
                tmp = new Token(SymbolType.CompUnit, null, 1);
            }
        }
        return buffer;
        /**************** end *********************/
    }


}
