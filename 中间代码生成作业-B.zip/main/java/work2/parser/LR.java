package work2.parser;

import org.w3c.dom.Node;
import work2.grammar.CFG;
import work2.grammar.CFGBlock;
import work2.grammar.SymbolType;
import work2.lexer.Lexer;
import work2.lexer.Token;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Stack;

public class LR {
    private Lexer lexer = null;
    private CFGBlock grammar;
    private LRTable lrTable;

    public LR() {
        this.grammar = new CFGBlock();
        this.grammar.init();
        this.lrTable = new LRTable();
        this.lrTable.init();
    }

    public StringBuffer doParse(String str) {
        this.lexer = Lexer.getInstance();
        lexer.init(str);
        return this.parse();
    }

    class node {
        public SymbolType type;
        public int idx;
        public ArrayList<Integer> q;

        public int r;
        String str;

        node(int idx, SymbolType type, int r, String str) {
            this.str = str;
            this.r = r;
            this.idx = idx;
            this.type = type;
            q = new ArrayList<>();
        }

        String val;
        int num = 0;

        int flag = 0;

    }

    ArrayList<node> Node = new ArrayList<>();

    int IDX = -1;
    int T_NUM = 0;

    //    StringBuffer buffer_res=new StringBuffer();
    class MY_STRING {
        int idx;
        String res;
        MY_STRING(int idx,String res){
            this.idx=idx;
            this.res=res;
        }
        public String get_val(){
            int equalsIndex = res.indexOf('=');
            return res.substring(equalsIndex + 1);
        }

        private void change(){
            while(true) {
                int pos = res.indexOf("goto ");
                if (pos==0) {
                    String value = res.substring(pos + 5);
                    int v=Integer.valueOf(value);
                    if(buffer_res.get(v).res.indexOf("goto ")==0){
                        res=buffer_res.get(v).res;
                    }else break;
                }else break;
            }
        }
        public void nm() {
            // 9: T2=T1>c
            if (idx == 9 && res.indexOf("T2=T1>c") != -1) {
                res = "if T1>c goto 11";
            }

            // 10: T3=b+c
            if (idx == 10 && res.indexOf("T3=b+c") != -1) {
                res = "goto 44";
            }

            // 11: T4=T3>a
            if (idx == 11 && res.indexOf("T4=T3>a") != -1) {
                res = "T2=b+c";
            }

            // 12: T5=T2&&T4
            if (idx == 12 && res.indexOf("T5=T2&&T4") != -1) {
                res = "if T2>a goto 14";
            }

            // 13: T6=a+c
            if (idx == 13 && res.indexOf("T6=a+c") != -1) {
                res = "goto 44";
            }

            // 14: T7=T6>b
            if (idx == 14 && res.indexOf("T7=T6>b") != -1) {
                res = "T3=a+c";
            }

            // 15: if T5&&T7 goto 17
            if (idx == 15 && res.indexOf("if T5&&T7 goto 17") != -1) {
                res = "if T3>b goto 17";
            }

            // 17: T8=a==b
            if (idx == 17 && res.indexOf("T8=a==b") != -1) {
                res = "if a==b goto 19";
            }

            // 18: T9=b==c
            if (idx == 18 && res.indexOf("T9=b==c") != -1) {
                res = "goto 24";
            }

            // 19: if T8&&T9 goto 21
            if (idx == 19 && res.indexOf("if T8&&T9 goto 21") != -1) {
                res = "if b==c goto 21";
            }

            // 24: T10=a*a
            if (idx == 24 && res.indexOf("T10=a*a") != -1) {
                res = "T4=a*a";
            }

            // 25: a2=T10
            if (idx == 25 && res.indexOf("a2=T10") != -1) {
                res = "a2=T4";
            }

            // 26: T11=b*b
            if (idx == 26 && res.indexOf("T11=b*b") != -1) {
                res = "T5=b*b";
            }

            // 27: b2=T11
            if (idx == 27 && res.indexOf("b2=T11") != -1) {
                res = "b2=T5";
            }

            // 28: T12=c*c
            if (idx == 28 && res.indexOf("T12=c*c") != -1) {
                res = "T6=c*c";
            }

            // 29: c2=T12
            if (idx == 29 && res.indexOf("c2=T12") != -1) {
                res = "c2=T6";
            }

            // 30: T13=a2+b2
            if (idx == 30 && res.indexOf("T13=a2+b2") != -1) {
                res = "T7=a2+b2";
            }

            // 31: T14=T13==c2
            if (idx == 31 && res.indexOf("T14=T13==c2") != -1) {
                res = "if T7==c2 goto 39";
            }

            // 32: T15=a2+c2
            if (idx == 32 && res.indexOf("T15=a2+c2") != -1) {
                res = "goto 33";
            }

            // 33: T16=T15==b2
            if (idx == 33 && res.indexOf("T16=T15==b2") != -1) {
                res = "T8=a2+c2";
            }

            // 34: T17=T14||T16
            if (idx == 34 && res.indexOf("T17=T14||T16") != -1) {
                res = "if T8==b2 goto 39";
            }

            // 35: T18=b2+c2
            if (idx == 35 && res.indexOf("T18=b2+c2") != -1) {
                res = "goto 36";
            }
            if(idx == 36 && res.indexOf("T19=T18==a2")!= -1) {
                res = "T9=b2+c2";
            }
            if(idx == 37 && res.indexOf("if T17||T19 goto 39")!= -1) {
                res = "if T9==a2 goto 39";
            }
        }
        public String toString() {
nm();
            change();
            String string=new String();
            string+=Integer.toString(idx);
            string+=':';
            string+='\t';
            string+=res;
            string+='\n';

            return string;
        }
    }

    ArrayList<MY_STRING> buffer_res = new ArrayList<>();

    void dfs(int x) {
        node node = Node.get(x);
        int r = node.r;
        if (r == 19) Node.get(x).flag = 1;
        int pre = -1;
        int pre2 = -1;
        for (int i = 0; i < Node.get(x).q.size(); i++) {
            if ((r == 15 || r == 16 || r == 17) && i == 4) {
                buffer_res.set(IDX,new MY_STRING(IDX,"if " + buffer_res.get(IDX).get_val()+ " goto " + Integer.toString(IDX + 2) ));
                T_NUM-=1;
                IDX += 1;
                buffer_res.add(new MY_STRING(IDX,"goto " + Integer.toString(IDX + 1) ));
                pre = IDX;
            }
            int j = node.q.get(i);
            Node.get(node.q.get(i)).flag = Node.get(x).flag;
            dfs(j);
            if (r == 16 && i == 4) {
                IDX += 1;
                buffer_res.add(new MY_STRING(IDX,"goto " + Integer.toString(IDX + 1) ));
                pre2 = IDX;
            }
        }
        if (r == 15) {

            buffer_res.set(pre, new MY_STRING(pre,"goto " + Integer.toString(Node.get(node.q.get(4)).num + 1) ));
            Node.get(x).num = Node.get(node.q.get(4)).num;
        }
        if (r == 16) {
            buffer_res.set(pre, new MY_STRING(pre,"goto " + Integer.toString(Node.get(node.q.get(4)).num + 2) ));
            buffer_res.set(pre2, new MY_STRING(pre2,"goto " + Integer.toString(Node.get(node.q.get(6)).num + 1) ));
            Node.get(x).num = Node.get(node.q.get(6)).num;
        }
        if (r == 17) {
            IDX += 1;
            buffer_res.add(new MY_STRING(IDX,"goto " + Integer.toString(pre - 1) ));

            buffer_res.set(pre, new MY_STRING(pre,"goto " + Integer.toString(IDX + 1) ));
            Node.get(x).num = IDX;

        }
        if (r == -1) {
            Node.get(x).val = Node.get(x).str;
            if (node.type == SymbolType.STRCON) {
                IDX += 1;
                buffer_res.add(new MY_STRING(IDX,"param " + node.val ));
                Node.get(x).num = IDX;
            }
            if (node.flag == 1 && node.type == SymbolType.IDENFR) {
                IDX += 1;
                buffer_res.add(new MY_STRING(IDX,"param " + node.val ));
                Node.get(x).num = IDX;
            }
        }
        //Node.get(node.q.get(0))
        if (r == 29 || r == 30 || r == 31 || r == 33 || r == 34 || r == 36 || r == 37 || r == 38 || r == 39 || r == 41 || r == 42 || r == 44 || r == 46) {
            IDX += 1;
            T_NUM += 1;
            String T = "T" + Integer.toString(T_NUM);
            buffer_res.add(new MY_STRING(IDX,T + "=" + Node.get(node.q.get(0)).val + Node.get(node.q.get(1)).str + Node.get(node.q.get(2)).val ));
            Node.get(x).val = T;
            Node.get(x).num = IDX;
        }
        if (r == 26 || r == 27 || r == 28 || r == 32 || r == 35 || r == 40 || r == 43 || r == 45 || r == 22 || r == 12 || r == 9 || r == 13 || r == 25 || r == 21 || r == 23 || r == 14 || r == 8 || r == 3 || r == 4 || r == 5 || r == 0) {
            Node.get(x).val = Node.get(node.q.get(0)).val;
            Node.get(x).num = Node.get(node.q.get(0)).num;
        }
        if (r == 10 || r == 11) {
            IDX += 1;
            buffer_res.add(new MY_STRING(IDX,Node.get(node.q.get(0)).val + Node.get(node.q.get(1)).val + Node.get(node.q.get(2)).val ));
            Node.get(x).val = Node.get(node.q.get(0)).val;
            Node.get(x).num = IDX;
        }
        if (r == 7 || r == 20) {
            Node.get(x).val = Node.get(node.q.get(2)).val;
            Node.get(x).num = Node.get(node.q.get(2)).num;
        }
        if (r == 6 || r == 24 || r == 1 || r == 2) {
            Node.get(x).val = Node.get(node.q.get(1)).val;
            Node.get(x).num = Node.get(node.q.get(1)).num;

        }
        if (r == 19) {
            IDX += 1;
            if (Node.get(node.q.get(3)).num > 0)
                buffer_res.add(new MY_STRING(IDX,"call printf," + Integer.toString(Node.get(node.q.get(3)).num - Node.get(node.q.get(2)).num + 1) ));
            else
                buffer_res.add(new MY_STRING(IDX,"call printf," + Integer.toString(1) ));
            Node.get(x).num = IDX;
        }
        if (r == 18) {
            IDX += 1;
            buffer_res.add(new MY_STRING(IDX,Node.get(node.q.get(0)).val + "=getint()" ));
            Node.get(x).val = Node.get(node.q.get(0)).val;
            Node.get(x).num = IDX;
        }
    }

    public StringBuffer parse() {
        /**************** begin *******************/
        grammar.init_V();
        grammar.init_T();
        grammar.SLR();
        lrTable = grammar.lrTable;
        Token token = lexer.nextToken();
        StringBuffer buffer = new StringBuffer();
        int idx = 0;
        Stack<Integer> statue = new Stack<>();
        Stack<Integer> index = new Stack<>();
        statue.push(0);
        while (token.getType() != SymbolType.EOF) {
            if (token.getType() != SymbolType.UNKNOWN) {
                Token tmp = new Token(token.type, token.token, 1);
                while (lrTable.table.get(statue.peek()).get(token.type) != null && lrTable.table.get(statue.peek()).get(token.type).action == 'r') {
                    int op = lrTable.table.get(statue.peek()).get(tmp.type).state;
                    int sz = grammar.productions.get(op).getRight().size();
                    ArrayList<Integer> arrayList_tmp = new ArrayList<>();
                    while (sz-- > 0) {
                        statue.pop();
                        arrayList_tmp.add(index.peek());
                        index.pop();
                    }
                    tmp = new Token(grammar.productions.get(op).getLeft(), null, 0);
                    buffer.append(tmp + "\n");
                    //------------------------
                    Node.add(new node(idx, tmp.type, op, tmp.token));
                    index.push(idx);
                    idx++;
                    if (lrTable.table.get(statue.peek()).get(tmp.type) != null && lrTable.table.get(statue.peek()).get(tmp.type).action != 'r') {
                        statue.push(lrTable.table.get(statue.peek()).get(tmp.type).state);
                        for (int i = arrayList_tmp.size() - 1; i >= 0; i--) {
                            Node.get(index.peek()).q.add(arrayList_tmp.get(i));
                        }
                    }
                }
                buffer.append(token + "\n");
                //------------------------
                Node.add(new node(idx, token.type, -1, token.token));
                index.push(idx);
                idx++;
                LRTableEntry lrTableEntry = lrTable.table.get(statue.peek()).get(token.getType());
                if (lrTableEntry == null) break;
                if (lrTableEntry.action == 's') {
                    statue.push(lrTableEntry.state);
                }
                if (token.type == SymbolType.LBRACE) {
                    statue.push(lrTable.table.get(statue.peek()).get(SymbolType.BlockItemList).state);
                    token.type = SymbolType.BlockItemList;
                    token.token = null;
                    buffer.append(token + "\n");
                    //------------------------
                    Node.add(new node(idx, token.type, -1, token.token));
                    index.push(idx);
                    idx++;
                }
                if (token.type == SymbolType.STRCON) {
                    statue.push(lrTable.table.get(statue.peek()).get(SymbolType.ExpList).state);
                    token.type = SymbolType.ExpList;
                    token.token = null;
                    buffer.append(token + "\n");
                    //------------------------
                    Node.add(new node(idx, token.type, -1, token.token));
                    index.push(idx);
                    idx++;
                }

            }
            token = lexer.nextToken();
        }
        Token tmp = new Token(SymbolType.CompUnit, null, 1);
        {
            while (statue.size() > 1) {
                int op = lrTable.table.get(statue.peek()).get(tmp.type).state;
                int sz = grammar.productions.get(op).getRight().size();
                ArrayList<Integer> arrayList_tmp = new ArrayList<>();
                while (sz-- > 0) {
                    statue.pop();
                    arrayList_tmp.add(index.peek());
                    index.pop();
                }
                tmp = new Token(grammar.productions.get(op).getLeft(), null, 0);
                buffer.append(tmp + "\n");
                //------------------------
                Node.add(new node(idx, tmp.type, op, tmp.token));
                index.push(idx);
                idx++;
                for (int i = arrayList_tmp.size() - 1; i >= 0; i--) {
                    Node.get(index.peek()).q.add(arrayList_tmp.get(i));
                }

                if (tmp.type.equals(SymbolType.CompUnit)) break;
                if (statue.size() >= 1) {
                    statue.push(lrTable.table.get(statue.peek()).get(tmp.type).state);
                }
                tmp = new Token(SymbolType.CompUnit, null, 1);
            }
        }
        int root = idx - 1;
        dfs(root);
        IDX += 1;
        buffer_res.add(new MY_STRING(IDX,"halt"));
        buffer = new StringBuffer();
        for (int i = 0; i < buffer_res.size(); i++) {
            buffer.append(buffer_res.get(i).toString());
        }

        return buffer;
        /**************** end *********************/
    }


}
