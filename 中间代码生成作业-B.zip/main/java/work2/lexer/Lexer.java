package work2.lexer;
import work2.grammar.SymbolType;

public class Lexer {
	private static Lexer instance;			//单实例
    private String string = null;			//要分析的字符串
    private int curPos;						//当前位置
    private int line;						//行	
    private StringBuffer lexeme = null;		//符号暂存处
    
    public static Lexer getInstance() {
        if(instance == null) {
            instance = new Lexer();
        }
        return instance;
    }
    
    public void init(String s) {
        instance.string = s;
        instance.curPos = 0;
        instance.line = 1;
        instance.lexeme = new StringBuffer();
    }
    
    //取得词法记号，并重置状态变量
    private Token getToken(SymbolType type) {
        String t = lexeme.toString();
        lexeme.setLength(0);
        return new Token(type, t, line);
    }
    
    
    //获取下一个token
    public Token nextToken() {
    	Token token= null;
    	//已经到达结尾
    	if(curPos >= string.length()) 
    		return null;
    	//去掉空白字符，换行，回车，制表符
    	char ch = string.charAt(curPos++);
        while(true) {
            if(ch==' ' || ch=='\n' || ch=='\r' || ch=='\t'){
                while (ch==' ' || ch=='\n' || ch=='\r' || ch=='\t') {
                    if (ch == '\n' || ch == '\r') line++;
                    if (curPos >= string.length())
                        return this.getToken(SymbolType.EOF);
                    ch = string.charAt(curPos++);
                }
            }
            else if (ch == '/' && curPos < string.length() && string.charAt(curPos) == '*') {
                // 跳过块注释的开始符号
                ch = string.charAt(++curPos);
                ch = string.charAt(++curPos); // 移动到注释内容的第一字符

                // 循环直到找到注释的结束符号
                while (curPos < string.length() - 1) {
                    if (ch == '*' && string.charAt(curPos + 1) == '/') {
                        // 跳过注释的结束符号
                        ch = string.charAt(++curPos);
                        ch = string.charAt(++curPos); // 移动到注释后的第一个字符
                        break;
                    } else {
                        // 如果遇到换行符，增加行号
                        if (ch == '\n' || ch == '\r') {
                            line++;
                        }
                        // 移动到下一个字符
                        ch = string.charAt(++curPos);
                    }
                }
            }
            else if (ch == '/' && curPos < string.length() && string.charAt(curPos) == '/') {
                // 跳过注释直到行尾
                while (ch != '\n' && ch != '\r' && curPos < string.length()) {
                    ch = string.charAt(curPos++);
                }
                // 如果注释后面有换行符，则增加行号并跳过换行符
                if (ch == '\n' || ch == '\r') {
                    line++;
                    ch = string.charAt(curPos++); // 移动到下一行的第一个字符
                }
                // 继续解析下一行
                while (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t') {
                    if (ch == '\n' || ch == '\r') line++;
                    if (curPos >= string.length())
                        return this.getToken(SymbolType.EOF);
                    ch = string.charAt(curPos++);
                }
            }
            else break;
        }
        //整型常量
    	if(Character.isDigit(ch)) {
    		this.lexeme.append(ch);
    		while(curPos < string.length()) {
    			ch = string.charAt(curPos++);
    			if(Character.isDigit(ch))
    				this.lexeme.append(ch);
    			else {
    				curPos--;
    				break;
    			}
    		}
    		return this.getToken(SymbolType.INTCON);
    	}
   	/*****************************begin*******************************/
        if (ch == '"') { // 检查是否为字符串常量的开始双引号
            this.lexeme.append(ch);
            boolean escape = false; // 用于处理转义字符
            while (curPos < string.length()) {
                ch = string.charAt(curPos++);
                if (ch == '"' && !escape) { // 如果遇到非转义的双引号，字符串结束
                    this.lexeme.append(ch);
                    return this.getToken(SymbolType.STRCON);
                } else if (ch == '\\' && !escape) { // 如果遇到转义字符
                    escape = true;
                } else {
                    escape = false;
                }
                this.lexeme.append(ch); // 将字符添加到词素中
            }
            return this.getToken(SymbolType.STRCON);
        }


        // 标识符 (Ident)
        if(Character.isJavaIdentifierStart(ch)) {
            this.lexeme.append(ch);
            while(curPos < string.length()) {
                ch = string.charAt(curPos);
                if(Character.isJavaIdentifierPart(ch)) {
                    this.lexeme.append(ch);
                    curPos++;
                } else {
                    break;
                }
            }
            switch (this.lexeme.toString()) {
                case "main":
                    return this.getToken(SymbolType.MAINTK);
                case "const":
                    return this.getToken(SymbolType.CONSTTK);
                case "int":
                    return this.getToken(SymbolType.INTTK);
                case "break":
                    return this.getToken(SymbolType.BREAKTK);
                case "continue":
                    return this.getToken(SymbolType.CONTINUETK);
                case "if":
                    return this.getToken(SymbolType.IFTK);
                case "else":
                    return this.getToken(SymbolType.ELSETK);
                case "void":
                    return this.getToken(SymbolType.VOIDTK);
                case "while":
                    return this.getToken(SymbolType.WHILETK);
                case "getint":
                    return this.getToken(SymbolType.GETINTTK);
                case "printf":
                    return this.getToken(SymbolType.PRINTFTK);
                case "return":
                    return this.getToken(SymbolType.RETURNTK);
                default:
                    // 如果不是关键字，则返回标识符
                    return this.getToken(SymbolType.IDENFR);
            }
        }

        switch (ch) {
            case '+':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.PLUS);
            case '-':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.MINU);
            case '*':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.MULT);
            case '/':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.DIV);
            case '%':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.MOD);
            case '=':
                this.lexeme.append(ch);
                if (curPos < string.length() && string.charAt(curPos) == '=') {
                    this.lexeme.append(string.charAt(curPos++));
                    return this.getToken(SymbolType.EQL);
                }
                return this.getToken(SymbolType.ASSIGN);
            case '!':
                this.lexeme.append(ch);
                if (curPos < string.length() && string.charAt(curPos) == '=') {
                    this.lexeme.append(string.charAt(curPos++));
                    return this.getToken(SymbolType.NEQ);
                }
                return this.getToken(SymbolType.NOT);
            case '<':
                this.lexeme.append(ch);
                if (curPos < string.length() && string.charAt(curPos) == '=') {
                    this.lexeme.append(string.charAt(curPos++));
                    return this.getToken(SymbolType.LEQ);
                }
                return this.getToken(SymbolType.LSS);
            case '>':
                this.lexeme.append(ch);
                if (curPos < string.length() && string.charAt(curPos) == '=') {
                    this.lexeme.append(string.charAt(curPos++));
                    return this.getToken(SymbolType.GEQ);
                }
                return this.getToken(SymbolType.GRE);
            case '&':
                this.lexeme.append(ch);
                if (curPos < string.length() && string.charAt(curPos) == '&') {
                    this.lexeme.append(string.charAt(curPos++));
                    return this.getToken(SymbolType.AND);
                }
                // Handle error for single '&'
                break;
            case '|':
                this.lexeme.append(ch);
                if (curPos < string.length() && string.charAt(curPos) == '|') {
                    this.lexeme.append(string.charAt(curPos++));
                    return this.getToken(SymbolType.OR);
                }
                // Handle error for single '|'
                break;
            case ';':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.SEMICN);
            case ',':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.COMMA);
            case '(':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.LPARENT);
            case ')':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.RPARENT);
            case '[':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.LBRACK);
            case ']':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.RBRACK);
            case '{':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.LBRACE);
            case '}':
                this.lexeme.append(ch);
                return this.getToken(SymbolType.RBRACE);
            // ... 其他符号的判断可以在这里继续添加 ...
        }
	
	/*****************************end*******************************/
        this.getToken(SymbolType.UNKNOWN);
        return this.nextToken();
    }
    
    private void error() {
        //输出错误信息
        System.out.println("Error in line " + line);
        while(true);
    }
}
